import { boot } from 'quasar/wrappers';
import { useDb } from 'src/composables/useDb';
import { startAllReplications } from 'src/services/database/replication';
import { supabase } from 'src/services/database/supabase';

export default boot(({ router }) => {
  const { initDb } = useDb();

  router.beforeEach(async (to) => {
    // 1. RESCATE MANUAL DEL TOKEN
    // Buscamos el token en cualquier parte del hash o de la ruta

    const fullHash = window.location.hash; // Esto trae todo lo que hay tras el primer #

    if (fullHash.includes('access_token=')) {
      console.log('🎯 Rescate manual: Token encontrado en el Hash.');

      // Extraemos los parámetros de la URL manualmente
      // Eliminamos el '#' o '#/' inicial para que URLSearchParams pueda leerlo
      const rawParams = fullHash.replace(/^#\/?/, '');
      const params = new URLSearchParams(rawParams);

      const accessToken = params.get('access_token');
      const refreshToken = params.get('refresh_token');

      if (accessToken && refreshToken) {
        // 2. INYECCIÓN FORZADA EN SUPABASE
        // Esto le dice a Supabase: "Aquí tienes los tokens, crea la sesión ya"
        const { data, error } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken,
        });

        if (data?.session) {
          console.log('✅ Sesión forzada con éxito para:', data.session.user.id);

          // 3. INICIALIZACIÓN DE RXDB
          const db = await initDb(data.session.user.id);

          // Llamamos al replicador
          if (navigator.onLine) {
            await startAllReplications(db, data.session.user.id);
          }

          // Limpiamos la URL y entramos
          return '/profile';
        }

        if (error) console.error('❌ Error al inyectar sesión:', error);
      }
      return '/auth/login';
    }

    // Lógica normal para el resto de las rutas
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (to.meta.requiresAuth && !session) {
      return '/auth/login';
    }
    return true;
  });

  /**
   * 3. ESCUCHA DE EVENTOS (Maneja SIGNED_IN / SIGNED_OUT en tiempo real)
   */
  supabase.auth.onAuthStateChange(async (event, session) => {
    if (event === 'SIGNED_IN' && session) {
      const db = await initDb(session.user.id);
      await startAllReplications(db, session.user.id);
      // Solo redirigimos si estamos en una página de auth
      if (
        router.currentRoute.value.path.startsWith('/auth') ||
        window.location.hash.includes('access_token')
      ) {
        await router.push('/profile');
      }
    }
    if (event === 'SIGNED_OUT') {
      // Limpieza total y redirección
      window.location.href = '/auth/login';
    }
  });
});
