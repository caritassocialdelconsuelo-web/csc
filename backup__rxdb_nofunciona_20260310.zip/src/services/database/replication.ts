import type {
  ReplicationPullOptions,
  ReplicationPushOptions,
  RxCollection,
  RxError,
  RxReplicationWriteToMasterRow,
} from 'rxdb';
import type { SupabaseReplicationCheckpoint } from 'src/supabase-replication';
import { supabase } from './supabase';
import type { Database } from './database';
import { SupabaseReplication } from './replicador/supabase-replication';

//Replicaciones con Supabase
//esto inicia un replicador

export const replicateCollection = async (
  collection: RxCollection,
  tableName: string,
  errorSuscriber: (err: RxError) => void,
  userId: string,
  pullOptions?: Omit<
    ReplicationPullOptions<unknown, SupabaseReplicationCheckpoint>,
    'handler' | 'stream$'
  > & {
    realtimePostgresChanges?: boolean;
    lastModifiedField?: string;
  },
  pushOptions?: Omit<ReplicationPushOptions<unknown>, 'handler' | 'batchSize'> & {
    updateHandler?: (row: RxReplicationWriteToMasterRow<unknown>) => Promise<boolean>;
  },
) => {
  const replication = new SupabaseReplication({
    supabaseClient: supabase,
    collection: collection,
    table: tableName,
    primaryKey: 'id',
    deletedField: 'registroBorrado',
    replicationIdentifier: `rep_${tableName}_${userId}_${import.meta.env.VITE_SUPABASE_URL}`, // TODO: Add Supabase user ID?
    pull: { ...pullOptions, lastModifiedField: 'actualizadoEn', batchSize: 100 }, // If absent, no data is pulled from Supabase
    push: pushOptions || {}, // If absent, no changes are pushed to Supabase
    live: true,
  });
  replication.error$.subscribe(errorSuscriber);
  await replication.awaitInitialReplication(); //Esto inicia el replicador
  return replication;
};

//Replica todo
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export async function startAllReplications(db: Database, userId: string) {
  // 1. Replicación de TPerfil
  /* const replicationState = await replicateCollection(
    db.perfiles,
    'TPerfil',
    (error) => {
      console.error('Error crítico en replicación TPerfil:', error);
    },
    userId,
  );

  // 2. Aquí añadirías otras tablas siguiendo el mismo patrón
  // startOtherTableReplication(db.otherCollection);

  return replicationState;*/
}
