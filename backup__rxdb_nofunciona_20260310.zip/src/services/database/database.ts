import type { RxDatabase } from 'rxdb';
import type { CTPerfil } from './schemas/perfil';

export type DbCollections = {
  perfiles: CTPerfil;
};

export type Database = RxDatabase<DbCollections>;
