import type { Database, DbCollections } from 'src/services/database/database';

import {
  cmPerfil,
  dmPerfil,
  slPerfil,
} from 'app/prompts/Creación de entidades/TypeScript Entidades IA/perfil';
import { readonly, ref } from 'vue';
import { createRxDatabase } from 'rxdb';
import { getRxStorageDexie } from 'rxdb/plugins/storage-dexie';
import { registerPerfilHooks } from 'src/services/database/schemas/perfil';

import { addRxPlugin } from 'rxdb';
import { wrappedValidateAjvStorage } from 'rxdb/plugins/validate-ajv';
import { disableWarnings } from 'rxdb/plugins/dev-mode';
//Detecta si estamos en modo de desarrollo o produccion

//if (import.meta.env.MODE == 'development') {
//  const { RxDBDevModePlugin } = await import('rxdb/plugins/dev-mode');
//  addRxPlugin(RxDBDevModePlugin);
//  disableWarnings();
//}

/**
 * Definimos la forma de nuestra base de datos para TypeScript
 */
//export type MyDatabaseCollections = {
//  tperfil: CTPerfil;
//};

// Instancia privada única (Singleton)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const dbInstance = ref<any>(null);

/**
 * Composable para gestionar la base de datos RxDB en Quasar
 */
export function useDb() {
  /**
   * Inicializa la base de datos local.
   * Se recomienda llamar esto en el Boot File o tras el Login.
   * @param userId El ID de Supabase para nombrar la base de datos de forma única.
   */
  const initDb = async (userId: string) => {
    // Si la instancia ya existe, la devolvemos inmediatamente
    if (dbInstance.value) {
      return dbInstance.value;
    }

    try {
      // 1. Creamos la base de datos con almacenamiento Dexie (IndexedDB)
      // Usamos el userId en el nombre para que si otro usuario inicia sesión
      // en el mismo navegador, no se mezclen los datos.

      /**
       * create database and collections
       */
      const db: Database = await createRxDatabase<DbCollections>({
        name: `db_pwa_${userId}`,
        storage: wrappedValidateAjvStorage({ storage: getRxStorageDexie() }),
        ignoreDuplicate: import.meta.env.NODE_ENV == 'DEV', // Permite Hot Module Replacement en desarrollo
      });

      await db.addCollections({
        perfiles: {
          schema: slPerfil,
          methods: dmPerfil,
          statics: cmPerfil,
        },
      });

      // Registramos tus Hooks (postInsert, preSave, etc.)
      registerPerfilHooks(db.perfiles);

      // Guardamos la instancia en el ref reactivo
      dbInstance.value = db;

      console.log('RxDB: Base de datos inicializada correctamente.');
      return db;
    } catch (error) {
      console.error('RxDB: Error al inicializar la base de datos:', error);
    }
  };

  /**
   * Cierra la base de datos y limpia la instancia.
   * Útil para el Logout.
   */
  const destroyDb = async () => {
    if (dbInstance.value) {
      await dbInstance.value.destroy();
      dbInstance.value = null;
      console.log('RxDB: Base de datos cerrada.');
    }
  };

  return {
    db: readonly(dbInstance), // readonly para evitar mutaciones accidentales desde fuera
    initDb,
    destroyDb,
  };
}
